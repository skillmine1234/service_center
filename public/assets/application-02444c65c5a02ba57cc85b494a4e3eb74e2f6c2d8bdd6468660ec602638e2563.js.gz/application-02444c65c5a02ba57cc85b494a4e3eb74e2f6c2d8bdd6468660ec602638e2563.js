(() => {
  // app/javascript/application.js
  alert("sdfsd");
})();

